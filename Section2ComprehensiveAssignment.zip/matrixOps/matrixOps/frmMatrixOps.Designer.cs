﻿namespace matrixOps
{
    partial class frmMatrixOps
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatrixA = new System.Windows.Forms.TextBox();
            this.txtMatrixB = new System.Windows.Forms.TextBox();
            this.txtMatrixC = new System.Windows.Forms.TextBox();
            this.lblMatrixA = new System.Windows.Forms.Label();
            this.lblMatrixB = new System.Windows.Forms.Label();
            this.lblMatrixC = new System.Windows.Forms.Label();
            this.btnMakeMatrixA = new System.Windows.Forms.Button();
            this.btnMakeMatrixB = new System.Windows.Forms.Button();
            this.txtRowsA = new System.Windows.Forms.TextBox();
            this.txtRowsB = new System.Windows.Forms.TextBox();
            this.txtColsA = new System.Windows.Forms.TextBox();
            this.txtColsB = new System.Windows.Forms.TextBox();
            this.btnMakeBIdentity = new System.Windows.Forms.Button();
            this.grpbxSelectOperation = new System.Windows.Forms.GroupBox();
            this.radioSubtract = new System.Windows.Forms.RadioButton();
            this.radioAdd = new System.Windows.Forms.RadioButton();
            this.radioMultiply = new System.Windows.Forms.RadioButton();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClearMatrices = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblRows = new System.Windows.Forms.Label();
            this.lblCols = new System.Windows.Forms.Label();
            this.grpbxSelectOperation.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatrixA
            // 
            this.txtMatrixA.Location = new System.Drawing.Point(41, 52);
            this.txtMatrixA.Multiline = true;
            this.txtMatrixA.Name = "txtMatrixA";
            this.txtMatrixA.ReadOnly = true;
            this.txtMatrixA.Size = new System.Drawing.Size(150, 150);
            this.txtMatrixA.TabIndex = 0;
            this.txtMatrixA.TabStop = false;
            // 
            // txtMatrixB
            // 
            this.txtMatrixB.Location = new System.Drawing.Point(269, 52);
            this.txtMatrixB.Multiline = true;
            this.txtMatrixB.Name = "txtMatrixB";
            this.txtMatrixB.ReadOnly = true;
            this.txtMatrixB.Size = new System.Drawing.Size(150, 150);
            this.txtMatrixB.TabIndex = 1;
            this.txtMatrixB.TabStop = false;
            // 
            // txtMatrixC
            // 
            this.txtMatrixC.Location = new System.Drawing.Point(497, 52);
            this.txtMatrixC.Multiline = true;
            this.txtMatrixC.Name = "txtMatrixC";
            this.txtMatrixC.ReadOnly = true;
            this.txtMatrixC.Size = new System.Drawing.Size(150, 150);
            this.txtMatrixC.TabIndex = 2;
            this.txtMatrixC.TabStop = false;
            // 
            // lblMatrixA
            // 
            this.lblMatrixA.AutoSize = true;
            this.lblMatrixA.Location = new System.Drawing.Point(36, 12);
            this.lblMatrixA.Name = "lblMatrixA";
            this.lblMatrixA.Size = new System.Drawing.Size(91, 25);
            this.lblMatrixA.TabIndex = 3;
            this.lblMatrixA.Text = "Matrix A";
            // 
            // lblMatrixB
            // 
            this.lblMatrixB.AutoSize = true;
            this.lblMatrixB.Location = new System.Drawing.Point(264, 12);
            this.lblMatrixB.Name = "lblMatrixB";
            this.lblMatrixB.Size = new System.Drawing.Size(91, 25);
            this.lblMatrixB.TabIndex = 4;
            this.lblMatrixB.Text = "Matrix B";
            // 
            // lblMatrixC
            // 
            this.lblMatrixC.AutoSize = true;
            this.lblMatrixC.Location = new System.Drawing.Point(492, 12);
            this.lblMatrixC.Name = "lblMatrixC";
            this.lblMatrixC.Size = new System.Drawing.Size(92, 25);
            this.lblMatrixC.TabIndex = 5;
            this.lblMatrixC.Text = "Matrix C";
            // 
            // btnMakeMatrixA
            // 
            this.btnMakeMatrixA.Location = new System.Drawing.Point(12, 242);
            this.btnMakeMatrixA.Name = "btnMakeMatrixA";
            this.btnMakeMatrixA.Size = new System.Drawing.Size(168, 41);
            this.btnMakeMatrixA.TabIndex = 5;
            this.btnMakeMatrixA.Text = "Make Matrix A";
            this.btnMakeMatrixA.UseVisualStyleBackColor = true;
            this.btnMakeMatrixA.Click += new System.EventHandler(this.btnMakeMatrixA_Click);
            // 
            // btnMakeMatrixB
            // 
            this.btnMakeMatrixB.Location = new System.Drawing.Point(12, 295);
            this.btnMakeMatrixB.Name = "btnMakeMatrixB";
            this.btnMakeMatrixB.Size = new System.Drawing.Size(168, 41);
            this.btnMakeMatrixB.TabIndex = 6;
            this.btnMakeMatrixB.Text = "Make Matrix B";
            this.btnMakeMatrixB.UseVisualStyleBackColor = true;
            this.btnMakeMatrixB.Click += new System.EventHandler(this.btnMakeMatrixB_Click);
            // 
            // txtRowsA
            // 
            this.txtRowsA.Location = new System.Drawing.Point(186, 242);
            this.txtRowsA.Name = "txtRowsA";
            this.txtRowsA.Size = new System.Drawing.Size(150, 31);
            this.txtRowsA.TabIndex = 1;
            this.txtRowsA.Text = "3";
            this.txtRowsA.Leave += new System.EventHandler(this.txtRowsA_Validating);
            // 
            // txtRowsB
            // 
            this.txtRowsB.Location = new System.Drawing.Point(186, 295);
            this.txtRowsB.Name = "txtRowsB";
            this.txtRowsB.Size = new System.Drawing.Size(150, 31);
            this.txtRowsB.TabIndex = 3;
            this.txtRowsB.Text = "3";
            this.txtRowsB.Leave += new System.EventHandler(this.txtRowsB_Validating);
            // 
            // txtColsA
            // 
            this.txtColsA.Location = new System.Drawing.Point(342, 242);
            this.txtColsA.Name = "txtColsA";
            this.txtColsA.Size = new System.Drawing.Size(150, 31);
            this.txtColsA.TabIndex = 2;
            this.txtColsA.Text = "3";
            this.txtColsA.Leave += new System.EventHandler(this.txtColsA_Validating);
            // 
            // txtColsB
            // 
            this.txtColsB.Location = new System.Drawing.Point(342, 295);
            this.txtColsB.Name = "txtColsB";
            this.txtColsB.Size = new System.Drawing.Size(150, 31);
            this.txtColsB.TabIndex = 4;
            this.txtColsB.Text = "3";
            this.txtColsB.Leave += new System.EventHandler(this.txtColsB_Validating);
            // 
            // btnMakeBIdentity
            // 
            this.btnMakeBIdentity.Location = new System.Drawing.Point(498, 295);
            this.btnMakeBIdentity.Name = "btnMakeBIdentity";
            this.btnMakeBIdentity.Size = new System.Drawing.Size(178, 41);
            this.btnMakeBIdentity.TabIndex = 7;
            this.btnMakeBIdentity.Text = "Make B Identity";
            this.btnMakeBIdentity.UseVisualStyleBackColor = true;
            this.btnMakeBIdentity.Click += new System.EventHandler(this.btnMakeBIdentity_Click);
            // 
            // grpbxSelectOperation
            // 
            this.grpbxSelectOperation.Controls.Add(this.radioSubtract);
            this.grpbxSelectOperation.Controls.Add(this.radioAdd);
            this.grpbxSelectOperation.Controls.Add(this.radioMultiply);
            this.grpbxSelectOperation.Location = new System.Drawing.Point(22, 340);
            this.grpbxSelectOperation.Name = "grpbxSelectOperation";
            this.grpbxSelectOperation.Size = new System.Drawing.Size(352, 68);
            this.grpbxSelectOperation.TabIndex = 8;
            this.grpbxSelectOperation.TabStop = false;
            this.grpbxSelectOperation.Text = "Select Operation";
            // 
            // radioSubtract
            // 
            this.radioSubtract.AutoSize = true;
            this.radioSubtract.Location = new System.Drawing.Point(222, 30);
            this.radioSubtract.Name = "radioSubtract";
            this.radioSubtract.Size = new System.Drawing.Size(123, 29);
            this.radioSubtract.TabIndex = 11;
            this.radioSubtract.TabStop = true;
            this.radioSubtract.Text = "Subtract";
            this.radioSubtract.UseVisualStyleBackColor = true;
            // 
            // radioAdd
            // 
            this.radioAdd.AutoSize = true;
            this.radioAdd.Location = new System.Drawing.Point(134, 30);
            this.radioAdd.Name = "radioAdd";
            this.radioAdd.Size = new System.Drawing.Size(81, 29);
            this.radioAdd.TabIndex = 10;
            this.radioAdd.TabStop = true;
            this.radioAdd.Text = "Add";
            this.radioAdd.UseVisualStyleBackColor = true;
            // 
            // radioMultiply
            // 
            this.radioMultiply.AutoSize = true;
            this.radioMultiply.Location = new System.Drawing.Point(10, 30);
            this.radioMultiply.Name = "radioMultiply";
            this.radioMultiply.Size = new System.Drawing.Size(117, 29);
            this.radioMultiply.TabIndex = 9;
            this.radioMultiply.TabStop = true;
            this.radioMultiply.Text = "Multiply";
            this.radioMultiply.UseVisualStyleBackColor = true;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(22, 415);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(150, 41);
            this.btnCalculate.TabIndex = 12;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClearMatrices
            // 
            this.btnClearMatrices.Location = new System.Drawing.Point(330, 415);
            this.btnClearMatrices.Name = "btnClearMatrices";
            this.btnClearMatrices.Size = new System.Drawing.Size(180, 41);
            this.btnClearMatrices.TabIndex = 13;
            this.btnClearMatrices.Text = "Clear &Matrices";
            this.btnClearMatrices.UseVisualStyleBackColor = true;
            this.btnClearMatrices.Click += new System.EventHandler(this.btnClearMatrices_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(516, 415);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(150, 41);
            this.btnExit.TabIndex = 14;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblRows
            // 
            this.lblRows.AutoSize = true;
            this.lblRows.Location = new System.Drawing.Point(181, 214);
            this.lblRows.Name = "lblRows";
            this.lblRows.Size = new System.Drawing.Size(65, 25);
            this.lblRows.TabIndex = 17;
            this.lblRows.Text = "Rows";
            // 
            // lblCols
            // 
            this.lblCols.AutoSize = true;
            this.lblCols.Location = new System.Drawing.Point(337, 214);
            this.lblCols.Name = "lblCols";
            this.lblCols.Size = new System.Drawing.Size(55, 25);
            this.lblCols.TabIndex = 18;
            this.lblCols.Text = "Cols";
            // 
            // frmMatrixOps
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(688, 468);
            this.Controls.Add(this.lblCols);
            this.Controls.Add(this.lblRows);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClearMatrices);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.grpbxSelectOperation);
            this.Controls.Add(this.btnMakeBIdentity);
            this.Controls.Add(this.txtColsB);
            this.Controls.Add(this.txtColsA);
            this.Controls.Add(this.txtRowsB);
            this.Controls.Add(this.txtRowsA);
            this.Controls.Add(this.btnMakeMatrixB);
            this.Controls.Add(this.btnMakeMatrixA);
            this.Controls.Add(this.lblMatrixC);
            this.Controls.Add(this.lblMatrixB);
            this.Controls.Add(this.lblMatrixA);
            this.Controls.Add(this.txtMatrixC);
            this.Controls.Add(this.txtMatrixB);
            this.Controls.Add(this.txtMatrixA);
            this.Name = "frmMatrixOps";
            this.Text = "Matrix Ops";
            this.Load += new System.EventHandler(this.frmMatrixOps_Load);
            this.grpbxSelectOperation.ResumeLayout(false);
            this.grpbxSelectOperation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatrixA;
        private System.Windows.Forms.TextBox txtMatrixB;
        private System.Windows.Forms.TextBox txtMatrixC;
        private System.Windows.Forms.Label lblMatrixA;
        private System.Windows.Forms.Label lblMatrixB;
        private System.Windows.Forms.Label lblMatrixC;
        private System.Windows.Forms.Button btnMakeMatrixA;
        private System.Windows.Forms.Button btnMakeMatrixB;
        private System.Windows.Forms.TextBox txtRowsA;
        private System.Windows.Forms.TextBox txtRowsB;
        private System.Windows.Forms.TextBox txtColsA;
        private System.Windows.Forms.TextBox txtColsB;
        private System.Windows.Forms.Button btnMakeBIdentity;
        private System.Windows.Forms.GroupBox grpbxSelectOperation;
        private System.Windows.Forms.RadioButton radioSubtract;
        private System.Windows.Forms.RadioButton radioAdd;
        private System.Windows.Forms.RadioButton radioMultiply;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClearMatrices;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblRows;
        private System.Windows.Forms.Label lblCols;
    }
}

