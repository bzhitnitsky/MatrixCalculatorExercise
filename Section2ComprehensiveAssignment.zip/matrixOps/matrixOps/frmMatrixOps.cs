﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace matrixOps
{
    public partial class frmMatrixOps : Form
    {
        double[,] matrixA;
        double[,] matrixB;
        double[,] matrixC;
        public frmMatrixOps()
        {
            InitializeComponent();
        }

        private bool IsInt32(TextBox textbox)
        {
            if (Int32.TryParse(textbox.Text, out int result))//if textbox contains an int
                return true;//return true meaning the value is valid
            textbox.Clear();//else clear the textbox
            textbox.Focus();//focus the textbox
            return false;//return false, the textbox value is not valid
        }
        private void txtRowsA_Validating(object sender, EventArgs e)
        {
            if (!IsInt32(txtRowsA))
            {
                MessageBox.Show("Please enter a valid integer.", "Operation cannot be completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtRowsB_Validating(object sender, EventArgs e)
        {
            if (!IsInt32(txtRowsB))
            {
                MessageBox.Show("Please enter a valid integer.", "Operation cannot be completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtColsA_Validating(object sender, EventArgs e)
        {
            if (!IsInt32(txtColsA))
            {
                MessageBox.Show("Please enter a valid integer.", "Operation cannot be completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtColsB_Validating(object sender, EventArgs e)
        {
            if (!IsInt32(txtColsB))
            {
                MessageBox.Show("Please enter a valid integer.", "Operation cannot be completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmMatrixOps_Load(object sender, EventArgs e)
        {

            radioMultiply.Select();//selects the multiply radio button
            txtRowsA.Focus();//sets focus to matrix a rows text box
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private double[,] generateMatrix(int rows, int cols)//generates a 2d array (matrix) of size according to rows and cols arguments
        {
            double[,] matrix = new double[rows, cols];//new blank 2d array of double of specified size
            Random autoRand = new Random();//new random number generator
            for (int i = 0; i < rows; i++)//for row
            {
                for (int j = 0; j < cols; j++)//for column
                {
                    matrix[i, j] = Math.Round(autoRand.NextDouble() * 10.0,1);//element at coordinate i,j in array is set to random double * 10
                                                                //(* 10 because the numbers are otherwise very small)
                }

            }
            return matrix;//return the newly generated matrix
        }
        private void outputMatrix(double[,] matrix, TextBox textbox)//takes a 2d array/matrix and textbox as arguments and outputs array to textbox.
        {
            textbox.Clear();//clear textbox
            for (int i = 0; i < matrix.GetLength(0); i++)//for loop for rows (gets number of rows from 0th (1st) dimension of array (GetLength(0).)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)//for loop for cols (gets number of cols from 1st (2nd) dimension of array (GetLength(1).)
                {
                    //textbox.Text += matrix[i, j].ToString("N1").PadLeft(4,' ') + " ";//add each element to the text box with 1 spaces after it 
                                                                                     //and format elements to have 1 decimal place
                    textbox.Text += matrix[i, j].ToString("N1").PadLeft(4, ' ') + " ";
                }
                textbox.Text += Environment.NewLine;//add a new line at the end of each row to the textbox
            }



        }
        private void btnMakeMatrixA_Click(object sender, EventArgs e)
        {
            matrixA = generateMatrix(int.Parse(txtRowsA.Text), int.Parse(txtColsA.Text));//generate the matrix
            outputMatrix(matrixA, txtMatrixA);//output matrix to appropriate box on btn click
        }

        private void btnMakeMatrixB_Click(object sender, EventArgs e)
        {
            matrixB = generateMatrix(int.Parse(txtRowsB.Text), int.Parse(txtColsB.Text));//generate the matrix
            outputMatrix(matrixB, txtMatrixB);//generate and output matrix to appropriate box on btn click
        }

        private void btnMakeBIdentity_Click(object sender, EventArgs e)
        {
            if (int.Parse(txtRowsB.Text) == int.Parse(txtColsB.Text))
            {
                matrixB = new double[int.Parse(txtRowsB.Text), int.Parse(txtColsB.Text)];//new blank 2d array of double of specified size
                for (int i = 0; i < matrixB.GetLength(0); i++)//for row
                {
                    for (int j = 0; j < matrixB.GetLength(1); j++)//for column
                    {
                        if (i == j)//if the element is one of the diagonal elements (where both coordinates are equal)
                            matrixB[i, j] = 1;//set element to 1
                        else
                            matrixB[i, j] = 0;//else set element to 0
                    }

                }
                outputMatrix (matrixB, txtMatrixB);//output generated identity matrix to txtbox txtMatrixB
            }
            else
                MessageBox.Show("Can only convert Matrix B to the identity matrix if the number of rows and columns are equal", "Operation cannot be completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool matrixIsNotNull(double[,] matrix, string name)//takes matrix and name of it as arguments, then tests if it is null
        {
            if (matrix != null)
            {
                return true;
            }
            else
                MessageBox.Show("Can not calculate because " + name + " is null. Please make sure both matrices are generated and try again.", "Operation cannot be completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
        }
        private bool areEqual(int one, int two, string error)//takes two ints (matrix dimensions) as arguments, returns true if they are equal or shows a error message 
        {
            if (one == two)
            {
                return true;
            }
            else
                MessageBox.Show(error, "Operation cannot be completed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            txtMatrixC.Clear();
            if (matrixIsNotNull(matrixA, "Matrix A") && matrixIsNotNull(matrixB, "Matrix B"))//if matrix A & B are not null
            {
                if (radioMultiply.Checked)//and multiplication is selected
                {   //test if # of rows in A match cols in B
                    if (areEqual(matrixA.GetLength(0), matrixB.GetLength(1), "The number of rows in Matrix A must match the number of columns in Matrix B.") && areEqual(matrixA.GetLength(1), matrixB.GetLength(0), "The number of columns in Matrix A must match the number of rows in Matrix B."))
                    {
                        matrixC = new double[matrixA.GetLength(0), matrixB.GetLength(1)];//give matrixC correct dimensions: (matrixA) cols and (matrixB) rows

                        for (int i = 0; i < matrixA.GetLength(0); i++)//for matrixA cols
                            for (int j = 0; j < matrixB.GetLength(1); j++)//for matrixB rows
                                matrixC[i, j] = 0;//fill matrixC with 0s to do += later
                        

                        for (int i = 0; i < matrixA.GetLength(0); i++)//for matrixA cols
                        {
                            for (int j = 0; j < matrixA.GetLength(0); j++)//for matrixB rows
                            {
                                for (int k = 0; k < matrixA.GetLength(1); k++)//for matrixA rows
                                    matrixC[i, j] += matrixA[i, k] * matrixB[k, j];//matrixC element += (matrixA(matrixA col,matrixA row)) * (matrixB(matrixA row,matrixB row))
                            }
                        }

                        outputMatrix(matrixC, txtMatrixC);//output matrixC to txtMatrixC textbox
                        
                    }

                }else if (radioAdd.Checked)
                {
                    if (areEqual(matrixA.GetLength(0), matrixB.GetLength(0),"Both Matrices must have the same dimensions.") && areEqual(matrixA.GetLength(1), matrixB.GetLength(1), "Both Matrices must have the same dimensions."))
                    {
                        matrixC = new double[matrixA.GetLength(0), matrixA.GetLength(1)];
                        for (int i = 0; i < matrixA.GetLength(0); i++)//for loop for rows (gets number of rows from 0th (1st) dimension of array (GetLength(0).)
                        {
                            for (int j = 0; j < matrixA.GetLength(1); j++)//for loop for cols (gets number of cols from 1st (2nd) dimension of array (GetLength(1).)
                            {
                                matrixC[i, j] = (matrixA[i, j] + matrixB[i, j]);//matrixC element = (matrixA element + matrixB element)
                            }
                            
                        }
                        outputMatrix(matrixC, txtMatrixC);//output matrixC to txtMatrixC textbox


                    }


                }
                else if (radioSubtract.Checked)
                {
                    if (areEqual(matrixA.GetLength(0), matrixB.GetLength(0), "Both Matrices must have the same dimensions.") && areEqual(matrixA.GetLength(1), matrixB.GetLength(1), "Both Matrices must have the same dimensions."))
                    {
                        matrixC = new double[matrixA.GetLength(0), matrixA.GetLength(1)];
                        for (int i = 0; i < matrixA.GetLength(0); i++)//for loop for rows (gets number of rows from 0th (1st) dimension of array (GetLength(0).)
                        {
                            for (int j = 0; j < matrixA.GetLength(1); j++)//for loop for cols (gets number of cols from 1st (2nd) dimension of array (GetLength(1).)
                            {
                                matrixC[i, j] = (matrixA[i, j] - matrixB[i, j]);//matrixC element = (matrixA element - matrixB element)
                            }

                        }
                        outputMatrix(matrixC, txtMatrixC);//output matrixC to txtMatrixC textbox
                    }


                }
            }
        }

        private void btnClearMatrices_Click(object sender, EventArgs e)//set all matrices to null, and clear all textboxes
        {
            matrixA = null;
            matrixB = null;
            matrixC = null;
            txtMatrixA.Clear();
            txtMatrixB.Clear();
            txtMatrixC.Clear();
        }
    }
}
